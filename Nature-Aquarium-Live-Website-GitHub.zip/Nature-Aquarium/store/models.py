from django.db import models
from django.utils.text import slugify

class Product(models.Model):
    CATEGORY_CHOICES = [
        ("fish", "Aquarium Fish"),
        ("tank", "Aquarium Tanks"),
        ("food", "Fish Food"),
        ("accessory", "Accessories"),
    ]
    name = models.CharField(max_length=140)
    slug = models.SlugField(unique=True, blank=True)
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES)
    description = models.TextField()
    price = models.DecimalField(max_digits=9, decimal_places=2)
    stock = models.PositiveIntegerField(default=0)
    image = models.ImageField(upload_to="products/", blank=True, null=True)
    featured = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def save(self, *args, **kwargs):
        if not self.slug:
            base = slugify(self.name) or "product"
            candidate = base
            number = 1
            while Product.objects.filter(slug=candidate).exclude(pk=self.pk).exists():
                number += 1
                candidate = f"{base}-{number}"
            self.slug = candidate
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name

class Service(models.Model):
    title = models.CharField(max_length=120)
    description = models.TextField()
    active = models.BooleanField(default=True)
    def __str__(self):
        return self.title

class Order(models.Model):
    STATUS_CHOICES = [
        ("placed", "Placed"), ("confirmed", "Confirmed"),
        ("shipped", "Shipped"), ("delivered", "Delivered"),
        ("cancelled", "Cancelled"),
    ]
    customer_name = models.CharField(max_length=120)
    phone = models.CharField(max_length=15)
    address = models.TextField()
    total = models.DecimalField(max_digits=10, decimal_places=2)
    payment_method = models.CharField(max_length=30, default="Cash on Delivery")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="placed")
    created_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return f"Order #{self.pk} - {self.customer_name}"

class OrderItem(models.Model):
    order = models.ForeignKey(Order, related_name="items", on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.PROTECT)
    quantity = models.PositiveIntegerField()
    price = models.DecimalField(max_digits=9, decimal_places=2)
    def __str__(self):
        return f"{self.product.name} x {self.quantity}"

class Contact(models.Model):
    name = models.CharField(max_length=120)
    phone = models.CharField(max_length=15)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return f"{self.name} ({self.phone})"
