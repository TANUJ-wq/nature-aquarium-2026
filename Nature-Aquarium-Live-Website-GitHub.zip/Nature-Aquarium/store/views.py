from decimal import Decimal
from django.contrib import messages
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST
from .models import Product, Service, Order, OrderItem, Contact

def _cart_details(request):
    cart = request.session.get("cart", {})
    items, total = [], Decimal("0.00")
    for product_id, quantity in cart.items():
        product = Product.objects.filter(pk=product_id).first()
        if product:
            qty = int(quantity)
            line_total = product.price * qty
            items.append({"product": product, "quantity": qty, "line_total": line_total})
            total += line_total
    return items, total

def home(request):
    featured = Product.objects.filter(featured=True, stock__gt=0)[:6]
    services = Service.objects.filter(active=True)[:3]
    return render(request, "store/home.html", {"featured": featured, "services": services})

def products(request):
    category = request.GET.get("category", "")
    search = request.GET.get("q", "").strip()
    product_list = Product.objects.filter(stock__gt=0)
    if category:
        product_list = product_list.filter(category=category)
    if search:
        product_list = product_list.filter(name__icontains=search)
    return render(request, "store/products.html", {"products": product_list, "category": category, "search": search})

def product_detail(request, slug):
    product = get_object_or_404(Product, slug=slug)
    return render(request, "store/product_detail.html", {"product": product})

@require_POST
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, pk=product_id)
    if product.stock < 1:
        messages.error(request, "This product is currently out of stock.")
    else:
        cart = request.session.get("cart", {})
        key = str(product_id)
        cart[key] = min(int(cart.get(key, 0)) + 1, product.stock)
        request.session["cart"] = cart
        messages.success(request, "Product added to your cart.")
    return redirect(request.POST.get("next") or "store:products")

def cart(request):
    items, total = _cart_details(request)
    return render(request, "store/cart.html", {"items": items, "total": total})

@require_POST
def update_cart(request, product_id):
    product = get_object_or_404(Product, pk=product_id)
    quantity = max(0, int(request.POST.get("quantity", 1)))
    cart = request.session.get("cart", {})
    if quantity == 0:
        cart.pop(str(product_id), None)
    else:
        cart[str(product_id)] = min(quantity, product.stock)
    request.session["cart"] = cart
    return redirect("store:cart")

@require_POST
def remove_from_cart(request, product_id):
    cart = request.session.get("cart", {})
    cart.pop(str(product_id), None)
    request.session["cart"] = cart
    return redirect("store:cart")

def checkout(request):
    items, total = _cart_details(request)
    if not items:
        messages.info(request, "Your cart is empty.")
        return redirect("store:products")
    if request.method == "POST":
        name = request.POST.get("customer_name", "").strip()
        phone = request.POST.get("phone", "").strip()
        address = request.POST.get("address", "").strip()
        if not name or not phone or not address:
            messages.error(request, "Please complete all fields.")
        elif not phone.isdigit() or not 10 <= len(phone) <= 15:
            messages.error(request, "Enter a valid phone number.")
        else:
            with transaction.atomic():
                # Recheck stock immediately before creating the order.
                for item in items:
                    product = Product.objects.select_for_update().get(pk=item["product"].pk)
                    if product.stock < item["quantity"]:
                        messages.error(request, f"Not enough stock for {product.name}.")
                        return redirect("store:cart")
                order = Order.objects.create(
                    customer_name=name, phone=phone, address=address,
                    total=total, payment_method="Cash on Delivery"
                )
                for item in items:
                    product = Product.objects.select_for_update().get(pk=item["product"].pk)
                    OrderItem.objects.create(order=order, product=product,
                                              quantity=item["quantity"], price=product.price)
                    product.stock -= item["quantity"]
                    product.save(update_fields=["stock"])
            request.session["cart"] = {}
            return redirect("store:order_success", order_id=order.pk)
    return render(request, "store/checkout.html", {"items": items, "total": total})

def order_success(request, order_id):
    order = get_object_or_404(Order, pk=order_id)
    return render(request, "store/order_success.html", {"order": order})

def contact(request):
    if request.method == "POST":
        name = request.POST.get("name", "").strip()
        phone = request.POST.get("phone", "").strip()
        message = request.POST.get("message", "").strip()
        if name and phone and message:
            Contact.objects.create(name=name, phone=phone, message=message)
            messages.success(request, "Thanks! Your message has been received.")
            return redirect("store:contact")
        messages.error(request, "Please fill in every field.")
    return render(request, "store/contact.html")
