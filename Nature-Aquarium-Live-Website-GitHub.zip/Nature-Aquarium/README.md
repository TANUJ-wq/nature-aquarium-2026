# Nature Aquarium

A beginner-friendly Django e-commerce project for a home-operated aquarium store.
Customers can browse aquarium fish, tanks and fish food, add products to a cart,
place demo/Cash-on-Delivery orders, and contact the store.

## Features
- Home page with featured aquarium products
- Product categories: Fish, Tanks, Fish Food and Accessories
- Product detail pages and stock display
- Session-based shopping cart
- Checkout using customer name and phone number (email is not required)
- Order records saved in SQLite
- Contact form
- Django admin to manage products, orders, services and contacts
- Responsive HTML/CSS layout

## Run locally
1. Install Python 3.10 or newer.
2. Open a terminal in this project folder.
3. Create and activate a virtual environment:
   - Windows: `py -m venv venv` then `venv\\Scripts\\activate`
   - macOS/Linux: `python3 -m venv venv` then `source venv/bin/activate`
4. Install dependencies: `pip install -r requirements.txt`
5. Create database tables: `python manage.py migrate`
6. Create an admin login: `python manage.py createsuperuser`
7. Start server: `python manage.py runserver`
8. Open `http://127.0.0.1:8000/` in your browser.
9. Admin panel: `http://127.0.0.1:8000/admin/`

## Add sample products
Log in to the admin panel and add products. Upload product images if desired.
Product image is optional; the site displays a placeholder when no image is uploaded.

## Important
This is an academic/demo project. Checkout records an order but does not collect
card details or process real online payments. Do not upload passwords, secret keys,
customer data, database files or private credentials to GitHub. Before public
deployment, set `DEBUG=False`, configure `ALLOWED_HOSTS`, and use an environment
variable for `SECRET_KEY`.


## Publish it as a live website (Render)
This repository includes `render.yaml` for a Render deployment and PostgreSQL database.
1. Upload the complete project folder to your own GitHub repository.
2. Create/sign in to a Render account and connect your GitHub account.
3. In Render, choose **New + → Blueprint**, select your Nature Aquarium GitHub repository, and deploy the blueprint.
4. Render will create the web service and database from `render.yaml`. Wait for the first deploy to finish.
5. Open the `onrender.com` URL shown by Render.
6. In the Render service Shell, run `python manage.py createsuperuser` to create your admin login. If the free plan does not provide Shell access, use a one-off job or deploy locally to create the admin user; do not share passwords publicly.
7. Product images uploaded to the app's local media folder are not durable across redeploys on a free web service. For a real public shop, configure persistent media/object storage before adding important images.

### Before publishing
- Confirm the Render service's actual hostname and update `ALLOWED_HOSTS` and `CSRF_TRUSTED_ORIGINS` if it differs from `nature-aquarium.onrender.com`.
- Free hosting and database availability/limits can change. Check the current plan and database terms in Render before deploying.
- This is a student/demo store, not a production payment system. Orders use Cash on Delivery demo flow only.
